import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from scrapy.exceptions import CloseSpider



class elcomercioItem(scrapy.Item):
    EnterpriseName = scrapy.Field() 
    
    

class elcomercioSpider(CrawlSpider):
    name = 'elcomercio'
    item_count = 0
    allowed_domain = ['https://elcomercio.pe/']
    start_urls = ["https://elcomercio.pe/archivo/todas/2014-01-01/?ref=ecr"]


    #//li[@class="siguiente"]/a/@data-path
    rules = (
        Rule(LinkExtractor(allow = (), restrict_xpaths=('//*[@id="fusion-app"]/div/div[12]/div[2]/div[5]/div/div[2]/ul/li[7]/a'))),
        Rule(LinkExtractor(allow = (), restrict_xpaths=('//a[@class="story-item__title block overflow-hidden primary-font line-h-xs mt-10"]')), callback='parse_item', follow=False)
    )

    def parse_item(self, response):
        elcomercio_item = elcomercioItem()
		#info de producto
        elcomercio_item['EnterpriseName'] = response.xpath('//*[@id="fusion-app"]/div/div[14]/div[2]/h1/text()').extract_first()
         
		
        
        self.item_count += 1
        if self.item_count > 2000 :
            raise CloseSpider('item_exceeded')
        yield elcomercio_item